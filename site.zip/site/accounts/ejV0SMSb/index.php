<?php

return [
    'email' => 'low.level.virtual.machine@gmail.com',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];