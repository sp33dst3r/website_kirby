<blockquote><?= $content ?></blockquote>
