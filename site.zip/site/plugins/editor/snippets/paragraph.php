<p><?= $content ?></p>
