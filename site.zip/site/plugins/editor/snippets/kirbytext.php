<?= $content->kirbytext();
