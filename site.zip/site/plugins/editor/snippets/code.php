<pre><code class="language-<?= $attrs->language()->or('text') ?>"><?= $content->html(false) ?></code></pre>
