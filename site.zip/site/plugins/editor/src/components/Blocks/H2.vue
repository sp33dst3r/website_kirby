<script>
import H1 from "./H1.vue";

export default {
  ...H1
};
</script>

<style lang="scss">
.k-editor-h2-block .k-editable-placeholder,
.k-editor-h2-block .k-editable .ProseMirror {
  font-size: 1.25rem;
  font-weight: 600;
  line-height: 1.35em;
}
.k-editor-h2-block .k-editor-block-options {
  top: 3px;
}
</style>
