export default {
  icon: "italic",
  label: "Italic",
  type: "italic",
  action: "toggleMark",
  args: ["italic"]
};
