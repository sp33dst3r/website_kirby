export default {
  icon: "bold",
  label: "Bold",
  type: "bold",
  action: "toggleMark",
  args: ["bold"]
};
