export default {
  icon: "url",
  label: "Link",
  type: "link",
  action: "link"
};
