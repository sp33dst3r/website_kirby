export default {
  icon: "code",
  label: "Code",
  type: "code",
  action: "toggleMark",
  args: ["code"]
};
