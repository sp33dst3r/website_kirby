# Info block extension

This demo block shows how to create a very simple block with a HTML input field and how to send changes from the input to the editor.

It creates a nice little info box.

## Installation

You can install this demo extension as a regular Kirby plugin by placing the info-block folder in site/plugins

## Docs

I've added lots of annotations to the index.php, index.css and index.js to give you a better idea how things work.
